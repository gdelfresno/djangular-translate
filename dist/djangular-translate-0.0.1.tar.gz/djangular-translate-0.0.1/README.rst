=====
djangular-translate
=====

Django module to implement i18n translations support for angularJS applications. 
Work together with angular module ng-django-translate 