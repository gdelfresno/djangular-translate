=====
djangular-translate
=====

Django module to implement i18n support for angularJS applications. 
Work together with angular module ng-django-translate 